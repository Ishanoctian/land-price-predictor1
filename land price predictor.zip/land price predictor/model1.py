from pyexpat import model
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split #for doing train test splitting
from sklearn.model_selection import StratifiedShuffleSplit #for doing train test splitting with minimal error
from sklearn.impute import SimpleImputer#this is to use imputer class
'''
IMPUTER CLASS---> it is used to impute(i.e. to fill the missing data point) and it helps to automate that process which increases 
                  efficiency
'''
from sklearn.metrics import mean_squared_error
housing = pd.read_csv("E:\machine learning project\land price predictor\housingData.csv")
#print(housing.head())
#TRAIN TEST SPLITTING----->
'''
1.here random_state is used so that data in test and train set is not changed when we re run program i.e. to prevent over fitting
2.but train_test_split has a drawback, as data will now remain constant if a features all the high values are gone in train set and all
the low values are in test set or vice-versa it will cause inaccuracy
3. to prevent this from happening we us StratifiedSuffelSplit in which we will give all the feature which can generate such an inaccuracy 
'''
''''''
chas = housing['CHAS'].copy()
train_set,test_set = train_test_split(housing,test_size=0.2,random_state=42)
_split = StratifiedShuffleSplit(n_splits=1,test_size=0.2,random_state=42)
for train_index,test_index in _split.split(housing,chas) :#WE HAVE CHOSEN CHAS HERE BECAUSE IT HAS VERY LESS 1 VALUE THAN 0
    strat_train_set = housing.loc[train_index]
    strat_test_set = housing.loc[test_index]

#LOOKING FOR CORELATIONS(WITH LAND PRICE(MEDV))---->
# work to be done in jupyter notebook so its commented out       
'''
corr_matrix = housing.corr()
a = corr_matrix['MEDV'].sort_values(ascending=False)
print(a)
#from above we found that MEDV has highest +ve correlation with RM,ZN and highest -ve correlation with LSTAT 
'''
#TRYING OUT ATTRIBUTE COMBINATIONS--->
#we have added this as it can be a very usefull feature as it gives us the value of tax per no_of_rooms
#housing['TAXRM'] = housing['TAX']/housing['RM'] 
#IF WE HAVE GOT SOME MISSING ATTRIBUTES WE HAVE THREE OPTIONS--->
'''
1. REMOVE THE WHOLE COLUMN(attribute) WHICH HAS MISSING ATTRIBUTES(ONLY RECOMMENDED WHEN IT IS NOT SIGNIFICANT ENOUGH)
   SYANTX---> a = housing.dropna(['feature_name',axis=1]) axis=1 is for column and axis=0 for rows
2. REMOVE THE MISSING DATA POINTS(ONLY IF THERE ARE FEW MISSING DATAPOINTS)
   SYNTAX---> a = housing.dropna(['feature_name'])
3. SET THE MISSING VALUES TO MEAN OR MEDIAN(SUITS IN MOST OF THE CASES i.e. when we cant use option 1,2)
   SYNTAX---> median = housing['feature_name'].median() use mean() for mean   
'''
#CREATING A PIPELINE----->
'''
it is used for evaluation on a data it provides a linear sequece of data transfoms which can be appended with ease
'''
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
my_pipeline = Pipeline([
    ('imputer',SimpleImputer(strategy="median") ),
    #we can add as many meathod(only the one which uses fit and transform)
    ('sta_scaler',StandardScaler())
])
housing_lables = strat_train_set['MEDV'].copy()
strat_train_set = strat_train_set.drop(['MEDV'],axis=1)
housing_tr=my_pipeline.fit_transform(strat_train_set)#now we have fitted the data of training set

#SELECTING A DESIRED MODEL FOR OUR LAND PRICE PREDICTOR and training it----->
from sklearn.ensemble import RandomForestRegressor
#housing.drop('MEDV',axis = 1)
model = RandomForestRegressor()
model.fit(housing_tr,housing_lables)
pre = model.predict(housing_tr)
#EVALUATING OUR MODEL WITH CROSS VALIDATION---->
'''
IN CROSS VALIDATION WE DIVIDE A SET IN N NO OF DATA SETS AND THEN TRAIN IT ON ONE SET AND THEN TEST IT ON OTHER AND CALCULATE THE RMSE
(ROOT MEAN SQUARED ERROR)
'''
from sklearn.model_selection import cross_val_score
scores = cross_val_score(model,housing_tr,housing_lables,scoring="neg_mean_squared_error",cv=10)#cv 10 means we want 10 data sets
rmse_scores = np.sqrt(-scores)#as scores was a -ve term so we write -scores to make it +ve

#FUNCTION TO PRINT SCORES ITS MEAN MEDIAN AND STANDARD DEVIATION--->
def print_stat(scores) :
   print("Scores : ",scores)
   print("mean : ",scores.mean())
   print("median : ",scores.median())
   print("standard deviation : ",scores.std())

#SAVING THE MODEL---->
# FROM DUMPING WE CAN SAVE IT AND USE IT IN OTHER PROGRAM 
from joblib import dump,load
dump(model,'land_price_predictor.joblib')

#TESTING THE MODEL---->
'''
test_x = strat_test_set.drop('MEDV',axis=1)
test_y = strat_test_set['MEDV'].copy()
prepared_test = my_pipeline.transform(test_x)#we have imputed the data to minimize error
final_prediction =model.predict(prepared_test)
mse = mean_squared_error(test_y,final_prediction)
rmse_final = np.sqrt(mse) 
'''
#LOADING DATA--->
'''
from joblib import load
model = load('land_price_predictor.joblib')
model.predict(a numpy array with all the arguments except medv)
''' 

   

