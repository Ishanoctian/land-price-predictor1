from joblib import load
import numpy as np
model = load('land_price_predictor.joblib')
lst=[0.02731	,0,	7.07,	0,	0.469,	6.421,	78.9,	4.9671,	2,	242,	17.8,	396.9,	9.14]
arr=np.array(lst)
arr.reshape(-1,1)
print(model.predict(arr))